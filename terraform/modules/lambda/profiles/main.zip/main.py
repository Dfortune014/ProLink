import json
import os
import boto3
from datetime import datetime
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
profiles_table = dynamodb.Table(os.environ['PROFILES_TABLE'])
users_table = dynamodb.Table(os.environ['USERS_TABLE'])

# CORS headers
CORS_HEADERS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Content-Type': 'application/json'
}

def get_user_id_from_event(event):
    """Extract user_id from JWT claims"""
    try:
        claims = event.get('requestContext', {}).get('authorizer', {}).get('jwt', {}).get('claims', {})
        return claims.get('sub')
    except:
        return None

def handler(event, context):
    # Try API Gateway HTTP API v2 format first
    request_context = event.get('requestContext', {})
    http_context = request_context.get('http', {})
    http_method = http_context.get('method')
    path = http_context.get('path') or event.get('rawPath')
    
    # Fallback to API Gateway v1 format if v2 format not found
    if not http_method:
        http_method = request_context.get('httpMethod')
    if not path:
        path = event.get('path') or request_context.get('path')
    
    try:
        # Handle OPTIONS (CORS preflight) first, before path normalization
        if http_method == 'OPTIONS':
            # Handle CORS preflight for any endpoint
            return {
                'statusCode': 200,
                'headers': CORS_HEADERS,
                'body': ''
            }
        
        # Normalize path (remove trailing slash, handle query params)
        if path:
            # Remove query string if present
            path = path.split('?')[0]
            path = path.rstrip('/')
        
        # Check if this is the username check endpoint
        if http_method == 'GET' and path and '/username/check' in path:
            return check_username_availability(event)
        elif http_method == 'POST' and path == '/profiles':
            return create_or_update_profile(event)
        elif http_method == 'GET' and path.startswith('/profiles/'):
            username = path.split('/')[-1]
            return get_public_profile(username)
        else:
            return {
                'statusCode': 405,
                'headers': CORS_HEADERS,
                'body': json.dumps({'error': 'Method not allowed'})
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': CORS_HEADERS,
            'body': json.dumps({
                'error': 'Internal server error',
                'message': str(e),
                'error_type': type(e).__name__
            })
        }

def create_or_update_profile(event):
    """POST /profiles - Create or update profile"""
    user_id = get_user_id_from_event(event)
    if not user_id:
        return {
            'statusCode': 401,
            'headers': CORS_HEADERS,
            'body': json.dumps({'error': 'Unauthorized'})
        }
    
    body = json.loads(event.get('body', '{}'))
    
    # Validate required fields
    username = body.get('username')
    if not username:
        return {
            'statusCode': 400,
            'headers': CORS_HEADERS,
            'body': json.dumps({'error': 'username is required'})
        }
    
    # Check if username is already taken by another user
    try:
        existing = profiles_table.get_item(Key={'username': username})
        if 'Item' in existing and existing['Item'].get('user_id') != user_id:
            return {
                'statusCode': 409,
                'headers': CORS_HEADERS,
                'body': json.dumps({'error': 'Username already taken'})
            }
    except ClientError as e:
        return {
            'statusCode': 500,
            'headers': CORS_HEADERS,
            'body': json.dumps({'error': f'Database error: {str(e)}'})
        }
    
    # Get or update user record
    try:
        user = users_table.get_item(Key={'user_id': user_id})
        claims = event.get('requestContext', {}).get('authorizer', {}).get('jwt', {}).get('claims', {})
        now = datetime.utcnow().isoformat()
        
        if 'Item' not in user:
            # Create user record
            user_item = {
                'user_id': user_id,
                'email': claims.get('email', ''),
                'username': username,
                'created_at': now,
                'updated_at': now,
                'profile_complete': True
            }
            # Add date_of_birth if provided
            date_of_birth = body.get('date_of_birth')
            if date_of_birth:
                user_item['date_of_birth'] = date_of_birth
            users_table.put_item(Item=user_item)
        else:
            # Update existing user record with username and date_of_birth if provided
            update_expression = "SET username = :u, updated_at = :up, profile_complete = :pc"
            expression_attribute_values = {
                ':u': username,
                ':up': now,
                ':pc': True
            }
            
            date_of_birth = body.get('date_of_birth')
            if date_of_birth:
                update_expression += ", date_of_birth = :dob"
                expression_attribute_values[':dob'] = date_of_birth
            
            users_table.update_item(
                Key={'user_id': user_id},
                UpdateExpression=update_expression,
                ExpressionAttributeValues=expression_attribute_values
            )
    except ClientError as e:
        return {
            'statusCode': 500,
            'headers': CORS_HEADERS,
            'body': json.dumps({'error': f'Database error: {str(e)}'})
        }
    
    # Prepare profile item
    profile_item = {
        'username': username,
        'user_id': user_id,
        'full_name': body.get('full_name', ''),
        'title': body.get('title', ''),
        'bio': body.get('bio', ''),
        'skills': body.get('skills', []),
        'social_links': body.get('social_links', {}),
        'profile_image_url': body.get('profile_image_url', ''),
        'email': body.get('email', ''),
        'phone': body.get('phone', ''),
        'resume_key': body.get('resume_key', ''),
        'show_email': body.get('show_email', False),
        'show_phone': body.get('show_phone', False),
        'show_resume': body.get('show_resume', False),
        'updated_at': datetime.utcnow().isoformat()
    }
    
    # Add date_of_birth if provided (for social logins completing profile)
    date_of_birth = body.get('date_of_birth')
    if date_of_birth:
        profile_item['date_of_birth'] = date_of_birth
    
    # Check if profile exists
    existing_profile = profiles_table.get_item(Key={'username': username})
    if 'Item' not in existing_profile:
        profile_item['created_at'] = datetime.utcnow().isoformat()
        print(f"Creating new profile record for username: {username}")
    else:
        # Preserve created_at from existing profile
        profile_item['created_at'] = existing_profile['Item'].get('created_at', datetime.utcnow().isoformat())
        print(f"Updating existing profile record for username: {username}")
    
    try:
        profiles_table.put_item(Item=profile_item)
        print(f"✓ Successfully saved profile record for username: {username}")
        return {
            'statusCode': 200,
            'headers': CORS_HEADERS,
            'body': json.dumps({'message': 'Profile saved successfully', 'profile': profile_item})
        }
    except ClientError as e:
        print(f"✗ ERROR saving profile record: {str(e)}")
        return {
            'statusCode': 500,
            'headers': CORS_HEADERS,
            'body': json.dumps({'error': f'Database error: {str(e)}'})
        }

def get_public_profile(username):
    """GET /profiles/{username} - Get public profile"""
    try:
        response = profiles_table.get_item(Key={'username': username})
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'headers': CORS_HEADERS,
                'body': json.dumps({'error': 'Profile not found'})
            }
        
        profile = response['Item']
        
        # Get user's links
        links_table = dynamodb.Table(os.environ.get('LINKS_TABLE', ''))
        links_response = links_table.query(
            KeyConditionExpression=Key('user_id').eq(profile['user_id']),
            FilterExpression='is_deleted = :false',
            ExpressionAttributeValues={':false': False}
        )
        links = sorted(links_response.get('Items', []), key=lambda x: x.get('order', 0))
        
        # Build public profile response
        public_profile = {
            'username': profile['username'],
            'full_name': profile.get('full_name', ''),
            'title': profile.get('title', ''),
            'bio': profile.get('bio', ''),
            'skills': profile.get('skills', []),
            'social_links': profile.get('social_links', {}),
            'profile_image_url': profile.get('profile_image_url', ''),
            'links': [{'title': l.get('title'), 'url': l.get('url')} for l in links]
        }
        
        # Add contact info if visible
        if profile.get('show_email'):
            public_profile['email'] = profile.get('email', '')
        if profile.get('show_phone'):
            public_profile['phone'] = profile.get('phone', '')
        if profile.get('show_resume') and profile.get('resume_key'):
            public_profile['resume_key'] = profile.get('resume_key')
        
        return {
            'statusCode': 200,
            'headers': CORS_HEADERS,
            'body': json.dumps(public_profile)
        }
    except ClientError as e:
        return {
            'statusCode': 500,
            'headers': CORS_HEADERS,
            'body': json.dumps({'error': f'Database error: {str(e)}'})
        }

def check_username_availability(event):
    """GET /username/check?username=xxx - Check if username is available"""
    try:
        # Handle both API Gateway v1 and v2 event formats
        query_params = event.get('queryStringParameters') or {}
        if query_params is None:
            query_params = {}
        
        # Also try multiValueQueryStringParameters (API Gateway v1 format)
        if not query_params and event.get('multiValueQueryStringParameters'):
            multi_params = event.get('multiValueQueryStringParameters', {})
            query_params = {k: v[0] if isinstance(v, list) and len(v) > 0 else v 
                          for k, v in multi_params.items()}
        
        username = query_params.get('username', '').strip().lower()
        
        if not username:
            return {
                'statusCode': 400,
                'headers': CORS_HEADERS,
                'body': json.dumps({'error': 'Username parameter is required'})
            }
        
        # Validate username format (alphanumeric, underscore, hyphen, 3-20 chars)
        import re
        if not re.match(r'^[a-z0-9_-]{3,20}$', username):
            return {
                'statusCode': 400,
                'headers': CORS_HEADERS,
                'body': json.dumps({
                    'available': False,
                    'error': 'Username must be 3-20 characters and contain only letters, numbers, underscores, and hyphens'
                })
            }
        
        try:
            # Check if username exists in profiles table
            response = profiles_table.get_item(Key={'username': username})
            available = 'Item' not in response
            
            return {
                'statusCode': 200,
                'headers': CORS_HEADERS,
                'body': json.dumps({
                    'available': available,
                    'username': username
                })
            }
            
        except ClientError as db_error:
            return {
                'statusCode': 500,
                'headers': CORS_HEADERS,
                'body': json.dumps({
                    'error': 'Database error',
                    'message': str(db_error)
                })
            }
        except Exception as db_error:
            return {
                'statusCode': 500,
                'headers': CORS_HEADERS,
                'body': json.dumps({
                    'error': 'Database error',
                    'message': str(db_error)
                })
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': CORS_HEADERS,
            'body': json.dumps({
                'error': 'Internal server error',
                'message': str(e),
                'error_type': type(e).__name__
            })
        }